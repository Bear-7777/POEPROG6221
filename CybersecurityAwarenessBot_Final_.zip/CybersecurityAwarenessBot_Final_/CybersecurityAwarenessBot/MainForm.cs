using System.Drawing;
using System.Media;

namespace CybersecurityAwarenessBot;

public sealed class MainForm : Form
{
    private readonly Color navy = Color.FromArgb(18, 25, 38);
    private readonly Color green = Color.FromArgb(40, 167, 112);
    private DatabaseService db;
    private bool databaseReady;
    private readonly TextBox chatInput = new();
    private readonly RichTextBox chatHistory = new();
    private readonly TextBox taskTitle = new();
    private readonly TextBox taskDescription = new();
    private readonly DateTimePicker reminderPicker = new();
    private readonly CheckBox setReminder = new() { Text = "Set reminder", AutoSize = true };
    private readonly ListBox taskList = new();
    private readonly ListBox activityList = new();
    private readonly Label dbStatus = new();
    private readonly Label quizQuestion = new();
    private readonly Label quizFeedback = new();
    private readonly Label quizScore = new();
    private readonly FlowLayoutPanel quizOptions = new();
    private int quizIndex, score;
    private bool quizAnswered;
    private string userName = "User";
    private readonly System.Windows.Forms.Timer reminderTimer = new() { Interval = 30000 };
    private readonly HashSet<int> notifiedReminders = [];

    public MainForm()
    {
        Text = "Cybersecurity Awareness Bot — Integrated Parts 1, 2 & 3";
        MinimumSize = new Size(950, 650);
        Size = new Size(1150, 780);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(242, 245, 249);
        Font = new Font("Segoe UI", 9.5F);
        BuildInterface();
        ConnectDatabase();
        reminderTimer.Tick += (_, _) => CheckReminders();
        reminderTimer.Start();
        Shown += (_, _) => PlayGreeting();
    }

    private void BuildInterface()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 86, BackColor = navy, Padding = new Padding(22, 12, 18, 8) };
        var heading = new Label { Text = "CYBERSECURITY AWARENESS BOT", ForeColor = Color.White, Font = new Font("Segoe UI", 17, FontStyle.Bold), AutoSize = true, Location = new Point(20, 12) };
        var sub = new Label { Text = "Stay alert. Stay safe. Learn, plan and protect.", ForeColor = Color.LightSkyBlue, AutoSize = true, Location = new Point(22, 49) };
        header.Controls.Add(heading); header.Controls.Add(sub);
        dbStatus.ForeColor = Color.White; dbStatus.AutoSize = true; dbStatus.Anchor = AnchorStyles.Top | AnchorStyles.Right; dbStatus.Location = new Point(790, 30);
        header.Controls.Add(dbStatus);
        Controls.Add(header);

        var tabs = new TabControl { Dock = DockStyle.Fill, Padding = new Point(15, 7) };
        tabs.TabPages.Add(BuildChatTab());
        tabs.TabPages.Add(BuildTasksTab());
        tabs.TabPages.Add(BuildQuizTab());
        tabs.TabPages.Add(BuildActivityTab());
        Controls.Add(tabs);
        header.BringToFront();
    }

    private TabPage BuildChatTab()
    {
        var page = new TabPage("Chat assistant");
        chatHistory.ReadOnly = true; chatHistory.Dock = DockStyle.Fill; chatHistory.BackColor = Color.White;
        chatHistory.Font = new Font("Segoe UI", 10);
        var top = new Panel { Dock = DockStyle.Top, Height = 75 };
        var nameLabel = new Label { Text = "Your name:", AutoSize = true, Location = new Point(14, 13) };
        var nameBox = new TextBox { Text = "User", Width = 180, Location = new Point(90, 9) };
        var setName = MakeButton("Set name", 285, 7, 100);
        setName.Click += (_, _) => { if (!string.IsNullOrWhiteSpace(nameBox.Text)) { userName = nameBox.Text.Trim(); AddChat($"Hello, {userName}! How can I help you stay safe online?", Color.ForestGreen); Log("Greeting", $"User name set to {userName}"); } };
        top.Controls.Add(nameLabel); top.Controls.Add(nameBox); top.Controls.Add(setName);
        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 58, Padding = new Padding(10) };
        chatInput.Dock = DockStyle.Fill; chatInput.PlaceholderText = "Ask about phishing, passwords, add a task, or start quiz...";
        var send = MakeButton("Send", 0, 0, 100); send.Dock = DockStyle.Right; send.Click += (_, _) => SendChat();
        chatInput.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; SendChat(); } };
        bottom.Controls.Add(chatInput); bottom.Controls.Add(send);
        page.Controls.Add(chatHistory); page.Controls.Add(bottom); page.Controls.Add(top);
        AddChat("Welcome! I can answer cybersecurity questions, manage tasks and reminders, run a quiz, and show your activity log.", Color.DarkGreen);
        AddChat("Try: 'add task review my privacy settings', 'remind me to update my password', or 'start quiz'.", Color.SteelBlue);
        return page;
    }

    private TabPage BuildTasksTab()
    {
        var page = new TabPage("Tasks & reminders");
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(14) };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60));
        var editor = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8) };
        editor.Controls.Add(new Label { Text = "Task title", AutoSize = true, Location = new Point(10, 12) });
        taskTitle.SetBounds(10, 36, 330, 28); editor.Controls.Add(taskTitle);
        editor.Controls.Add(new Label { Text = "Description", AutoSize = true, Location = new Point(10, 78) });
        taskDescription.Multiline = true; taskDescription.ScrollBars = ScrollBars.Vertical; taskDescription.SetBounds(10, 102, 330, 90); editor.Controls.Add(taskDescription);
        setReminder.Location = new Point(10, 207); editor.Controls.Add(setReminder);
        reminderPicker.SetBounds(10, 235, 220, 28); reminderPicker.Format = DateTimePickerFormat.Custom; reminderPicker.CustomFormat = "yyyy-MM-dd HH:mm"; reminderPicker.ShowUpDown = true; editor.Controls.Add(reminderPicker);
        var add = MakeButton("Add task", 10, 280, 105); add.Click += (_, _) => AddTaskFromFields();
        var update = MakeButton("Update selected", 125, 280, 135); update.Click += (_, _) => UpdateSelectedTask();
        var delete = MakeButton("Delete selected", 10, 322, 135); delete.Click += (_, _) => DeleteSelectedTask();
        var complete = MakeButton("Mark complete", 155, 322, 135); complete.Click += (_, _) => CompleteSelectedTask();
        editor.Controls.Add(add); editor.Controls.Add(update); editor.Controls.Add(delete); editor.Controls.Add(complete);
        var right = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8) };
        right.Controls.Add(new Label { Text = "Your cybersecurity tasks", Font = new Font(Font, FontStyle.Bold), AutoSize = true, Location = new Point(10, 12) });
        taskList.SetBounds(10, 42, 540, 400); taskList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        taskList.SelectedIndexChanged += (_, _) => LoadSelectedTask(); right.Controls.Add(taskList);
        var refresh = MakeButton("Refresh tasks", 10, 455, 120); refresh.Anchor = AnchorStyles.Bottom | AnchorStyles.Left; refresh.Click += (_, _) => RefreshTasks(); right.Controls.Add(refresh);
        layout.Controls.Add(editor, 0, 0); layout.Controls.Add(right, 1, 0); page.Controls.Add(layout);
        return page;
    }

    private TabPage BuildQuizTab()
    {
        var page = new TabPage("Cybersecurity quiz");
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(30) };
        quizScore.Text = "Question 0 of 12  |  Score: 0"; quizScore.Font = new Font(Font, FontStyle.Bold); quizScore.SetBounds(25, 20, 600, 30);
        quizQuestion.Font = new Font("Segoe UI", 15, FontStyle.Bold); quizQuestion.SetBounds(25, 70, 850, 90); quizQuestion.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        quizOptions.SetBounds(25, 175, 850, 230); quizOptions.FlowDirection = FlowDirection.TopDown; quizOptions.WrapContents = false; quizOptions.AutoScroll = true; quizOptions.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        quizFeedback.SetBounds(25, 420, 850, 55); quizFeedback.ForeColor = Color.DarkGreen; quizFeedback.Font = new Font(Font, FontStyle.Bold);
        var start = MakeButton("Start / Restart quiz", 25, 490, 170); start.Click += (_, _) => StartQuiz();
        var next = MakeButton("Next question", 210, 490, 140); next.Click += (_, _) => NextQuestion();
        panel.Controls.Add(quizScore); panel.Controls.Add(quizQuestion); panel.Controls.Add(quizOptions); panel.Controls.Add(quizFeedback); panel.Controls.Add(start); panel.Controls.Add(next);
        page.Controls.Add(panel); ShowQuizIntro(); return page;
    }

    private TabPage BuildActivityTab()
    {
        var page = new TabPage("Activity log");
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };
        panel.Controls.Add(new Label { Text = "Recent actions recorded by the bot", AutoSize = true, Font = new Font(Font, FontStyle.Bold), Location = new Point(12, 12) });
        activityList.SetBounds(12, 45, 900, 520); activityList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        var refresh = MakeButton("Refresh log", 12, 580, 120); refresh.Anchor = AnchorStyles.Bottom | AnchorStyles.Left; refresh.Click += (_, _) => RefreshActivity();
        panel.Controls.Add(activityList); panel.Controls.Add(refresh); page.Controls.Add(panel); return page;
    }

    private Button MakeButton(string text, int x, int y, int width)
    {
        var b = new Button { Text = text, Location = new Point(x, y), Size = new Size(width, 34), BackColor = green, ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
        b.FlatAppearance.BorderSize = 0; return b;
    }

    private void ConnectDatabase()
    {
        try
        {
            db = new DatabaseService(); db.InitializeDatabase(); databaseReady = true;
            dbStatus.Text = "● MySQL connected"; dbStatus.ForeColor = Color.LightGreen;
            Log("Application", "Part 3 application started");
            RefreshTasks(); RefreshActivity();
        }
        catch (Exception ex)
        {
            databaseReady = false; dbStatus.Text = "● MySQL not connected"; dbStatus.ForeColor = Color.Orange;
            AddChat("Database connection is not ready: " + ex.Message + " See README.md to configure MySQL.", Color.DarkOrange);
            MessageBox.Show("The application opened, but MySQL is not connected.\n\n" + ex.Message +
                "\n\nFollow the database setup in README.md, then restart the application.", "Database setup required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void SendChat()
    {
        string input = chatInput.Text.Trim(); if (input.Length == 0) return;
        chatInput.Clear(); AddChat($"{userName}: {input}", Color.Black);
        string intent = NlpProcessor.GetIntent(input);
        string response;
        switch (intent)
        {
            case "exit": response = "Thanks for chatting. Stay safe online!"; break;
            case "activity":
                RefreshActivity();
                response = !databaseReady ? "Connect MySQL to view your activity history." :
                    activityList.Items.Count == 0 ? "No activity recorded yet." :
                    "Here are your recent actions:\n" + string.Join("\n", activityList.Items.Cast<object>().Take(10).Select((item, i) => $"{i + 1}. {item}"));
                break;
            case "list_tasks": RefreshTasks(); response = "I refreshed your task list. Open Tasks & reminders to view it."; break;
            case "add_task":
                var title = NlpProcessor.ExtractTaskTitle(input);
                if (databaseReady) { try { db.AddTask(title, "Added through the chat assistant.", null); Log("Task added", title); RefreshTasks(); response = $"Task added: {title}."; } catch (Exception ex) { response = "I could not save that task: " + ex.Message; } }
                else response = "Task storage needs a MySQL connection. Configure the database first.";
                break;
            case "reminder":
                var reminderTitle = NlpProcessor.ExtractTaskTitle(input);
                if (databaseReady) { try { DateTime when = DateTime.Now.AddDays(1); db.AddTask(reminderTitle, "Reminder created through the chat assistant.", when); Log("Reminder set", $"{reminderTitle} — {when:g}"); RefreshTasks(); response = $"Task added and reminder set for tomorrow ({when:g}): {reminderTitle}. You can change the reminder date in Tasks & reminders."; } catch (Exception ex) { response = "I could not save the reminder: " + ex.Message; } }
                else response = "Reminder storage needs a MySQL connection. Configure the database first.";
                break;
            case "quiz": StartQuiz(); response = "The cybersecurity quiz is ready. Open the Cybersecurity quiz tab and answer each question."; break;
            case "password": response = ResponseHandler.GetResponse(input); break;
            case "phishing": response = ResponseHandler.GetResponse(input); break;
            case "safe_browsing": response = ResponseHandler.GetResponse(input); break;
            case "malware": response = ResponseHandler.GetResponse(input); break;
            case "social_engineering": response = ResponseHandler.GetResponse(input); break;
            case "two_factor": response = "Two-factor authentication adds another verification step to your password. Turn it on for important accounts."; break;
            case "greeting": response = $"Hello, {userName}! I'm ready to help you stay safe online."; break;
            case "help": response = "I can explain passwords, phishing, malware, safe browsing and 2FA. You can also add tasks, set reminders, start the quiz, or view the activity log."; break;
            default:
                response = ResponseHandler.GetResponse(input);
                if (response.StartsWith("I didn't quite understand", StringComparison.OrdinalIgnoreCase))
                {
                    response = SentimentHelper.GetSupportiveResponse(input) ?? response;
                }
                break;
        }
        AddChat("Bot: " + response, Color.DarkGreen);
        if (intent != "activity" && intent != "list_tasks") Log("Chat", $"Intent: {intent}; input: {input}");
    }

    private void AddChat(string text, Color color)
    {
        chatHistory.SelectionStart = chatHistory.TextLength; chatHistory.SelectionLength = 0;
        chatHistory.SelectionColor = color; chatHistory.AppendText(text + Environment.NewLine + Environment.NewLine);
        chatHistory.SelectionColor = chatHistory.ForeColor; chatHistory.ScrollToCaret();
    }

    private void AddTaskFromFields()
    {
        if (!databaseReady) { MessageBox.Show("Connect MySQL before adding tasks."); return; }
        if (string.IsNullOrWhiteSpace(taskTitle.Text)) { MessageBox.Show("Enter a task title."); return; }
        try
        {
            DateTime? reminder = setReminder.Checked ? reminderPicker.Value : null;
            int id = db.AddTask(taskTitle.Text.Trim(), taskDescription.Text.Trim(), reminder);
            Log(reminder.HasValue ? "Reminder set" : "Task added", taskTitle.Text.Trim());
            taskTitle.Clear(); taskDescription.Clear(); setReminder.Checked = false; RefreshTasks();
            MessageBox.Show($"Task saved successfully (ID: {id}).");
        }
        catch (Exception ex) { MessageBox.Show("Could not save task: " + ex.Message); }
    }

    private CyberTask SelectedTask => taskList.SelectedItem as CyberTask;

    private void LoadSelectedTask()
    {
        if (SelectedTask is not CyberTask task) return;
        taskTitle.Text = task.Title; taskDescription.Text = task.Description;
        setReminder.Checked = task.ReminderAt.HasValue;
        if (task.ReminderAt.HasValue) reminderPicker.Value = task.ReminderAt.Value < DateTime.Now ? DateTime.Now : task.ReminderAt.Value;
    }

    private void UpdateSelectedTask()
    {
        if (!databaseReady || SelectedTask is not CyberTask task) { MessageBox.Show("Select a task first and ensure MySQL is connected."); return; }
        if (string.IsNullOrWhiteSpace(taskTitle.Text)) { MessageBox.Show("Enter a task title."); return; }
        try
        {
            task.Title = taskTitle.Text.Trim(); task.Description = taskDescription.Text.Trim();
            task.ReminderAt = setReminder.Checked ? reminderPicker.Value : null;
            db.UpdateTask(task); Log("Task updated", task.Title); RefreshTasks();
        }
        catch (Exception ex) { MessageBox.Show("Could not update task: " + ex.Message); }
    }

    private void DeleteSelectedTask()
    {
        if (!databaseReady || SelectedTask is not CyberTask task) { MessageBox.Show("Select a task first."); return; }
        if (MessageBox.Show($"Delete '{task.Title}'?", "Confirm delete", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
        try { db.DeleteTask(task.Id); Log("Task deleted", task.Title); RefreshTasks(); taskTitle.Clear(); taskDescription.Clear(); }
        catch (Exception ex) { MessageBox.Show("Could not delete task: " + ex.Message); }
    }

    private void CompleteSelectedTask()
    {
        if (!databaseReady || SelectedTask is not CyberTask task) { MessageBox.Show("Select a task first."); return; }
        try { task.IsCompleted = true; db.UpdateTask(task); Log("Task completed", task.Title); RefreshTasks(); }
        catch (Exception ex) { MessageBox.Show("Could not update task: " + ex.Message); }
    }

    private void RefreshTasks()
    {
        if (!databaseReady) return;
        try { taskList.Items.Clear(); foreach (var task in db.GetTasks()) taskList.Items.Add(task); }
        catch (Exception ex) { AddChat("Could not load tasks: " + ex.Message, Color.DarkRed); }
    }

    private void Log(string action, string details)
    {
        if (!databaseReady || db == null) return;
        try { db.AddActivity(action, details); }
        catch (Exception ex) { System.Diagnostics.Debug.WriteLine("Activity log error: " + ex.Message); }
    }

    private void RefreshActivity()
    {
        if (!databaseReady) return;
        try { activityList.Items.Clear(); foreach (string item in db.GetActivity()) activityList.Items.Add(item); }
        catch (Exception ex) { MessageBox.Show("Could not load activity: " + ex.Message); }
    }

    private void StartQuiz()
    {
        quizIndex = 0; score = 0; quizAnswered = false;
        ShowQuestion();
        Log("Quiz started", "Cybersecurity mini-game");
    }

    private void ShowQuizIntro()
    {
        quizQuestion.Text = "Test your cybersecurity knowledge.\nPress Start / Restart quiz to begin.";
        quizOptions.Controls.Clear(); quizFeedback.Text = ""; quizScore.Text = "12 questions | Multiple-choice and true/false";
    }

    private void ShowQuestion()
    {
        if (quizIndex >= QuizService.Questions.Count) { FinishQuiz(); return; }
        quizAnswered = false; quizFeedback.Text = "";
        var q = QuizService.Questions[quizIndex];
        quizScore.Text = $"Question {quizIndex + 1} of {QuizService.Questions.Count}  |  Score: {score}";
        quizQuestion.Text = q.Question; quizOptions.Controls.Clear();
        for (int i = 0; i < q.Options.Length; i++)
        {
            int selected = i;
            var option = new RadioButton { Text = q.Options[i], AutoSize = true, Font = new Font(Font.FontFamily, 11), Padding = new Padding(5), Tag = selected };
            option.CheckedChanged += (_, _) => { if (option.Checked) AnswerQuestion(selected); };
            quizOptions.Controls.Add(option);
        }
    }

    private void AnswerQuestion(int selected)
    {
        if (quizAnswered) return;
        quizAnswered = true;
        var q = QuizService.Questions[quizIndex];
        bool correct = selected == q.CorrectIndex;
        if (correct) score++;
        quizFeedback.ForeColor = correct ? Color.DarkGreen : Color.DarkRed;
        quizFeedback.Text = (correct ? "Correct! " : "Not quite. ") + q.Explanation;
        foreach (Control c in quizOptions.Controls) if (c is RadioButton r) r.Enabled = false;
    }

    private void NextQuestion()
    {
        if (quizIndex >= QuizService.Questions.Count) { StartQuiz(); return; }
        if (!quizAnswered) { MessageBox.Show("Choose an answer before moving to the next question."); return; }
        quizIndex++; ShowQuestion();
    }

    private void FinishQuiz()
    {
        quizQuestion.Text = $"Quiz completed!\nYou scored {score} out of {QuizService.Questions.Count}.";
        quizOptions.Controls.Clear();
        double percent = score * 100.0 / QuizService.Questions.Count;
        quizFeedback.ForeColor = Color.DarkGreen;
        quizFeedback.Text = percent >= 80 ? "Excellent work — you have strong cybersecurity awareness!" :
            percent >= 50 ? "Good effort — review the explanations and keep learning." :
            "Keep learning — revisit the cybersecurity tips and try again.";
        quizScore.Text = $"Final score: {score}/{QuizService.Questions.Count} ({percent:0}%)";
        Log("Quiz completed", $"Score: {score}/{QuizService.Questions.Count}");
        quizIndex = QuizService.Questions.Count;
    }

    private void CheckReminders()
    {
        if (!databaseReady) return;
        try
        {
            foreach (var task in db.GetTasks().Where(t => !t.IsCompleted && t.ReminderAt.HasValue &&
                         t.ReminderAt.Value <= DateTime.Now && !notifiedReminders.Contains(t.Id)))
            {
                notifiedReminders.Add(task.Id);
                MessageBox.Show($"Reminder: {task.Title}\n{task.Description}", "Cybersecurity task reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Log("Reminder triggered", task.Title);
            }
        }
        catch { /* A temporary database issue must not close the application. */ }
    }

    private void PlayGreeting()
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Assets", "greeting.wav");
            if (File.Exists(path)) using (var player = new SoundPlayer(path)) player.Play();
        }
        catch { /* Audio is optional; the GUI remains usable without it. */ }
    }
}
