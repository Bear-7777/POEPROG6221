# Cybersecurity Awareness Bot — Part 3

A Windows Forms C# application that extends the Part 2 Cybersecurity Awareness Bot. It includes a chat assistant, MySQL-backed task and reminder management, a cybersecurity quiz, basic rule-based NLP, and an activity log.

## Requirements

- Windows 10/11
- Visual Studio 2022 (or another IDE that supports .NET 8 Windows Forms)
- .NET 8 SDK
- MySQL Server 8 or compatible MySQL installation
- MySQL Workbench (recommended, for running `database.sql`)

## Project structure

```text
CybersecurityAwarenessBot/
├── CybersecurityAwarenessBot.csproj
├── Program.cs                 # Windows Forms entry point
├── MainForm.cs                # GUI, chat, task manager, quiz and activity log
├── Models.cs                  # Task and quiz data models
├── DatabaseService.cs         # MySQL database operations
├── NlpProcessor.cs            # Text normalisation and intent detection
├── QuizService.cs             # 12 cybersecurity quiz questions
├── ResponseHandler.cs         # Part 2 predefined response knowledge
├── InputValidator.cs          # Part 2 input validation helper
├── VoiceGreeting.cs           # Optional Part 2 WAV greeting helper
├── Assets/
│   ├── greeting.wav           # Optional voice greeting, if supplied
│   └── README-audio.txt       # Audio instructions
├── appsettings.example.json   # Example MySQL connection settings
├── database.sql               # Database and table creation script
└── .github/workflows/ci.yml   # Build workflow
```

## 1. Set up MySQL

1. Install and start MySQL Server.
2. Open MySQL Workbench and connect to your local server.
3. Open `database.sql` and execute the whole script. It creates the `cybersecurity_bot` database and the `tasks` and `activity_log` tables.
4. In the project folder, make a copy of `appsettings.example.json` and name the copy `appsettings.json`.
5. Open `appsettings.json` and replace `CHANGE_ME` with your own MySQL password. If your MySQL username, port or server is different, update those values too.
6. Do not submit or publish your real database password to GitHub. `appsettings.json` is excluded by `.gitignore`.

The application also creates the two tables automatically after it connects, but the database itself must exist first.

## 2. Open and run the application

### Visual Studio 2022

1. Open Visual Studio.
2. Select **Open a project or solution** and select `CybersecurityAwarenessBot.csproj`.
3. Allow NuGet packages to restore.
4. Make sure the project is set as the startup project.
5. Press **F5** or click **Start**.

### Command line

Open a terminal in the folder containing `CybersecurityAwarenessBot.csproj`:

```bash
dotnet restore
dotnet build
dotnet run
```

This is a Windows Forms project and must be run on Windows. On non-Windows platforms, .NET may be able to restore/build with Windows targeting enabled, but it cannot run the Windows desktop interface.

## 3. How to use the application

### Chat assistant and NLP
Type a question or command into the Chat assistant tab and press Enter or Send. Examples:

- `How do I create a strong password?`
- `What is phishing?`
- `Add task review my privacy settings`
- `Remind me to update my password`
- `Show my tasks`
- `Start quiz`
- `Show activity log`

The NLP component converts input to lowercase, removes punctuation, checks keywords and patterns, and identifies an intent. It is a basic rule-based NLP simulation, not a machine-learning model.

When a reminder command is sent through chat, the bot creates a task with a reminder for the following day. To choose a specific date and time, use the Tasks & reminders tab.

### Tasks and reminders
- Enter a task title and optional description.
- Tick **Set reminder** and choose a date/time if needed.
- Select **Add task** to save it.
- Select an existing task to edit it, mark it complete, or delete it.
- Reminders are checked while the application is running. A notification appears when a due reminder is reached. The app checks every 30 seconds.

### Cybersecurity mini-game
Select **Start / Restart quiz**. There are 12 multiple-choice and true/false questions. The bot gives immediate feedback and an explanation after each answer, then displays the final score.

### Activity log
Open the Activity log tab and select Refresh log. The application records task creation, updates, deletion, completion, reminders, chat interactions, and quiz events. The latest 100 events are displayed.

## 4. Troubleshooting

- **MySQL not connected:** Check that MySQL Server is running, the database exists, and `appsettings.json` contains the correct connection details.
- **Access denied:** Check the MySQL username and password and confirm that the account has permission to use `cybersecurity_bot`.
- **Missing appsettings.json:** Copy `appsettings.example.json` to `appsettings.json` in the project folder. Rebuild or run again so the file is copied to the output folder.
- **No voice greeting:** Audio is optional. Put a valid WAV file named `greeting.wav` in `Assets`. The application continues without it.
- **No reminder popup:** The app must be running, connected to MySQL, and the reminder time must have passed. The app checks reminders every 30 seconds.

## Part 2 integration

The project retains the Part 2 response handler, input validator and optional voice greeting helper. The Part 2 console-specific interface was replaced by Windows Forms because the Part 3 brief explicitly requires a GUI. The chat assistant continues to provide the existing cybersecurity topics and adds task, reminder, quiz and activity-log commands.

## Suggested demonstration for assessment

1. Launch the app and show the GUI.
2. Ask the bot about phishing or password safety.
3. Add a task and set a reminder using the task form.
4. Show that the task is stored in MySQL.
5. Mark a task as complete and demonstrate updating/deleting a task.
6. Start the quiz, answer several questions, and show the final score.
7. Type `show activity log` and open the Activity log tab.
8. Demonstrate a natural-language variation such as `Can you remind me to update my password?`.

## Notes

- This project uses MySQL, as required by the Part 3 brief.
- Keep your personal MySQL password private; submit `appsettings.example.json`, not your configured `appsettings.json`.
- The project is an educational awareness tool and does not replace professional security software.


## Integration note

Original Part 1/2 `ChatBot.cs` and `ConsoleUI.cs` have been preserved as legacy console source files. The Windows Forms entry point remains `Program.cs` and the GUI uses `MainForm.cs`. See the repository root README for history and setup.
