using System.Text.RegularExpressions;

namespace CybersecurityAwarenessBot;

/// <summary>Lightweight rule-based NLP using normalisation, keywords and patterns.</summary>
public static class NlpProcessor
{
    private const string Replacement = "";

    public static string Normalize(string input)
    {
        string value = (input ?? "").ToLowerInvariant().Trim();
        value = Regex.Replace(value, @"[^\w\s\-:]", " ");
        return Regex.Replace(value, @"\s+", " ");
    }

    public static string GetIntent(string input)
    {
        string text = Normalize(input);
        if (text is "exit" or "quit" or "bye" or "goodbye") return "exit";
        if (ContainsAny(text, "show activity", "activity log", "what have you done")) return "activity";
        if (ContainsAny(text, "show tasks", "view tasks", "list tasks", "my tasks")) return "list_tasks";
        if (ContainsAny(text, "add task", "create task", "new task")) return "add_task";
        if (ContainsAny(text, "remind me", "set reminder", "reminder for")) return "reminder";
        if (ContainsAny(text, "start quiz", "play quiz", "cybersecurity quiz", "mini game")) return "quiz";
        if (ContainsAny(text, "password", "passphrase")) return "password";
        if (ContainsAny(text, "phishing", "suspicious email", "fake email")) return "phishing";
        if (ContainsAny(text, "safe browsing", "browse safely", "website safety")) return "safe_browsing";
        if (ContainsAny(text, "malware", "virus", "ransomware")) return "malware";
        if (ContainsAny(text, "social engineering", "impersonation", "scam")) return "social_engineering";
        if (ContainsAny(text, "two factor", "2fa", "multi factor", "authentication")) return "two_factor";
        if (ContainsAny(text, "hello", "hi ") || text == "hi") return "greeting";
        if (ContainsAny(text, "help", "what can you do")) return "help";
        return "unknown";
    }

    public static string ExtractTaskTitle(string input)
    {
        string title = Regex.Replace(input ?? "", @"(?i)\b(add|create|new)\s+(a\s+)?task\b", Replacement, RegexOptions.None, TimeSpan.FromSeconds(1)).Trim(' ', '.', ':', '-', '"');
        title = Regex.Replace(title, @"(?i)\b(remind me to|reminder to)\b", "").Trim();
        return string.IsNullOrWhiteSpace(title) ? "Review cybersecurity settings" : title;
    }

    private static bool ContainsAny(string text, params string[] terms) =>
        terms.Any(term => text.Contains(term, StringComparison.OrdinalIgnoreCase));
}
