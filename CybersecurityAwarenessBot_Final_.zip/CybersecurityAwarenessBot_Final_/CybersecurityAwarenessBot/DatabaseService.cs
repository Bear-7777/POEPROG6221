using MySqlConnector;
using System.Text.Json;

namespace CybersecurityAwarenessBot;

/// <summary>MySQL data access for tasks, reminders and the activity log.</summary>
public sealed class DatabaseService
{
    private readonly string _connectionString;

    public DatabaseService()
    {
        string configPath = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        if (!File.Exists(configPath))
            throw new FileNotFoundException("appsettings.json was not found. Copy appsettings.example.json and configure MySQL.");
        using JsonDocument doc = JsonDocument.Parse(File.ReadAllText(configPath));
        _connectionString = doc.RootElement.GetProperty("ConnectionStrings")
            .GetProperty("MySql").GetString() ?? "";
        if (string.IsNullOrWhiteSpace(_connectionString) ||
            _connectionString.Contains("CHANGE_ME", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Configure your MySQL username and password in appsettings.json first.");
    }

    private MySqlConnection CreateConnection() => new(_connectionString);

    public void TestConnection()
    {
        using var connection = CreateConnection();
        connection.Open();
        using var command = new MySqlCommand("SELECT 1", connection);
        command.ExecuteScalar();
    }

    public void InitializeDatabase()
    {
        using var connection = CreateConnection();
        connection.Open();
        const string tasksSql = """
            CREATE TABLE IF NOT EXISTS tasks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(180) NOT NULL,
                description TEXT NULL,
                reminder_at DATETIME NULL,
                is_completed BOOLEAN NOT NULL DEFAULT FALSE,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """;
        const string logSql = """
            CREATE TABLE IF NOT EXISTS activity_log (
                id INT AUTO_INCREMENT PRIMARY KEY,
                action_type VARCHAR(80) NOT NULL,
                details TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """;
        using (var cmd = new MySqlCommand(tasksSql, connection)) cmd.ExecuteNonQuery();
        using (var cmd = new MySqlCommand(logSql, connection)) cmd.ExecuteNonQuery();
    }

    public List<CyberTask> GetTasks()
    {
        var tasks = new List<CyberTask>();
        using var connection = CreateConnection();
        connection.Open();
        const string sql = "SELECT id,title,description,reminder_at,is_completed FROM tasks ORDER BY is_completed, reminder_at IS NULL, reminder_at, id DESC";
        using var cmd = new MySqlCommand(sql, connection);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            tasks.Add(new CyberTask {
                Id = reader.GetInt32("id"),
                Title = reader.GetString("title"),
                Description = reader.IsDBNull(reader.GetOrdinal("description")) ? "" : reader.GetString("description"),
                ReminderAt = reader.IsDBNull(reader.GetOrdinal("reminder_at")) ? null : reader.GetDateTime("reminder_at"),
                IsCompleted = reader.GetBoolean("is_completed")
            });
        }
        return tasks;
    }

    public int AddTask(string title, string description, DateTime? reminder)
    {
        using var connection = CreateConnection();
        connection.Open();
        const string sql = "INSERT INTO tasks(title,description,reminder_at) VALUES(@title,@description,@reminder); SELECT LAST_INSERT_ID();";
        using var cmd = new MySqlCommand(sql, connection);
        cmd.Parameters.AddWithValue("@title", title);
        cmd.Parameters.AddWithValue("@description", description);
        cmd.Parameters.AddWithValue("@reminder", reminder.HasValue ? reminder.Value : DBNull.Value);
        return Convert.ToInt32(cmd.ExecuteScalar());
    }

    public void UpdateTask(CyberTask task)
    {
        using var connection = CreateConnection();
        connection.Open();
        const string sql = "UPDATE tasks SET title=@title, description=@description, reminder_at=@reminder, is_completed=@done WHERE id=@id";
        using var cmd = new MySqlCommand(sql, connection);
        cmd.Parameters.AddWithValue("@title", task.Title);
        cmd.Parameters.AddWithValue("@description", task.Description);
        cmd.Parameters.AddWithValue("@reminder", task.ReminderAt.HasValue ? task.ReminderAt.Value : DBNull.Value);
        cmd.Parameters.AddWithValue("@done", task.IsCompleted);
        cmd.Parameters.AddWithValue("@id", task.Id);
        cmd.ExecuteNonQuery();
    }

    public void DeleteTask(int id)
    {
        using var connection = CreateConnection();
        connection.Open();
        using var cmd = new MySqlCommand("DELETE FROM tasks WHERE id=@id", connection);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }

    public void AddActivity(string action, string details)
    {
        using var connection = CreateConnection();
        connection.Open();
        using var cmd = new MySqlCommand("INSERT INTO activity_log(action_type,details) VALUES(@action,@details)", connection);
        cmd.Parameters.AddWithValue("@action", action);
        cmd.Parameters.AddWithValue("@details", details);
        cmd.ExecuteNonQuery();
    }

    public List<string> GetActivity()
    {
        var entries = new List<string>();
        using var connection = CreateConnection();
        connection.Open();
        using var cmd = new MySqlCommand("SELECT action_type,details,created_at FROM activity_log ORDER BY id DESC LIMIT 100", connection);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            entries.Add($"{reader.GetDateTime("created_at"):yyyy-MM-dd HH:mm:ss} | {reader.GetString("action_type")} | {reader.GetString("details")}");
        return entries;
    }
}
