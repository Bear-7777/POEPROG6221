namespace CybersecurityAwarenessBot;

/// <summary>Simple Part 2-style sentiment keyword detection for user support.</summary>
public static class SentimentHelper
{
    public static string? GetSupportiveResponse(string input)
    {
        string text = NlpProcessor.Normalize(input);
        if (new[] { "worried", "scared", "afraid", "anxious", "nervous", "stressed", "confused", "frustrated" }
            .Any(word => text.Split(' ').Contains(word)))
            return "It's understandable to feel concerned about online threats. We can work through a security topic together. Would you like advice about phishing, passwords or account safety?";
        if (new[] { "happy", "excited", "confident", "great", "thank you", "thanks" }
            .Any(word => text.Contains(word, StringComparison.OrdinalIgnoreCase)))
            return "Glad to hear that! Keep practicing good cybersecurity habits. Ask me about passwords, phishing, or try the quiz.";
        return null;
    }
}
