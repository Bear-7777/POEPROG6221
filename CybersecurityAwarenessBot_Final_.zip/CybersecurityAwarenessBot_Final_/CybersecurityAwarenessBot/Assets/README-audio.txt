OPTIONAL VOICE GREETING

The application can play an optional WAV greeting when it opens.
1. Record a short greeting, for example: "Welcome to the Cybersecurity Awareness Bot. Stay alert and stay safe."
2. Save or convert the recording as WAV format.
3. Name the file greeting.wav.
4. Place it in this Assets folder.
5. Rebuild and run the project.

The app still works if the WAV file is not present.