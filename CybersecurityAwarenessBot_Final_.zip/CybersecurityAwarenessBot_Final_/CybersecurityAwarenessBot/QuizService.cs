namespace CybersecurityAwarenessBot;

public static class QuizService
{
    public static readonly List<QuizQuestion> Questions =
    [
        new() { Question="What is phishing?", Options=["A type of computer screen","A fake message designed to steal information","A safe backup method","A software update"], CorrectIndex=1, Explanation="Phishing messages impersonate trusted people or organisations to steal data." },
        new() { Question="Which password is strongest?", Options=["password123","Bear2026","T!mber-River-92#Cloud","12345678"], CorrectIndex=2, Explanation="Long, unique passwords with varied characters are harder to guess." },
        new() { Question="True or false: You should reuse one password for every account.", Options=["True","False"], CorrectIndex=1, Explanation="Use a different password for each account so one breach does not expose all accounts." },
        new() { Question="What does HTTPS indicate?", Options=["The connection is encrypted","The website is always honest","The device has no malware","The page is government-owned"], CorrectIndex=0, Explanation="HTTPS encrypts data in transit, but it does not prove a site is trustworthy." },
        new() { Question="What should you do with an unexpected attachment?", Options=["Open it immediately","Forward it to friends","Verify the sender before opening","Disable antivirus"], CorrectIndex=2, Explanation="Unexpected attachments can contain malware. Verify the sender first." },
        new() { Question="What is malware?", Options=["A malicious program","A strong password","A network cable","A backup schedule"], CorrectIndex=0, Explanation="Malware is software designed to damage, disrupt or gain unauthorised access." },
        new() { Question="What is the safest response to a suspicious link?", Options=["Click to check it","Enter your password","Avoid it and verify through a trusted channel","Share it publicly"], CorrectIndex=2, Explanation="Do not click suspicious links; contact the organisation using known details." },
        new() { Question="What does 2FA add to an account?", Options=["A second verification step","A second username","Unlimited storage","Faster internet"], CorrectIndex=0, Explanation="Two-factor authentication requires an additional proof of identity." },
        new() { Question="True or false: Public Wi-Fi is always safe for banking.", Options=["True","False"], CorrectIndex=1, Explanation="Public Wi-Fi can be risky. Use trusted networks and secure connections." },
        new() { Question="What is social engineering?", Options=["Building websites","Manipulating people into revealing information","Repairing computers","Encrypting files"], CorrectIndex=1, Explanation="Social engineering uses deception to influence people into unsafe actions." },
        new() { Question="Why install security updates?", Options=["To remove the keyboard","To fix known vulnerabilities","To make passwords public","To stop all spam"], CorrectIndex=1, Explanation="Updates often patch weaknesses attackers could exploit." },
        new() { Question="What should you do if an account may be compromised?", Options=["Ignore it","Share your password","Change the password from a trusted device and report it","Delete all emails"], CorrectIndex=2, Explanation="Secure the account promptly, enable 2FA and report the incident." }
    ];
}
