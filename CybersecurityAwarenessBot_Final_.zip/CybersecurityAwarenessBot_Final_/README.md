# Cybersecurity Awareness Bot — Integrated Parts 1, 2 and 3

## Which project to submit/run

Open **`CybersecurityAwarenessBot/CybersecurityAwarenessBot.csproj`** in Visual Studio 2022. This is the final Windows Forms application (Part 3), with the original Part 1/2 `ChatBot.cs` and `ConsoleUI.cs` source files preserved. Those two original classes are legacy console components and are **not invoked by the Windows Forms interface**. The GUI now **calls the original `ResponseHandler.GetResponse`** for earlier cybersecurity responses and common original phrases. The GUI also includes simple sentiment detection (`SentimentHelper.cs`), keyword-based NLP, voice greeting, and the audio asset.



## Setup

1. Install Visual Studio 2022 with .NET desktop development and .NET 8 SDK.
2. Install and start MySQL Server. Run `CybersecurityAwarenessBot/database.sql` in MySQL Workbench.
3. Copy `CybersecurityAwarenessBot/appsettings.example.json` to `CybersecurityAwarenessBot/appsettings.json` and replace `CHANGE_ME` with your local MySQL password. **Never commit appsettings.json.**
4. Open the final `.csproj` in Visual Studio; restore NuGet packages, build and run.
5. Test chatbot, quiz, tasks/reminders, activity log and database.

## GitHub safety

`appsettings.json`, `.vs/`, `bin/`, and `obj/` are excluded from this archive. The project `.gitignore` excludes local secrets and build artifacts. Do not upload your MySQL password or personal test data.

## Note on verification

The uploaded Part 3 ZIP included compiled output, indicating a prior local build. This newly assembled integrated ZIP has **not** been compiled in this environment. Build and test the integrated copy in Visual Studio before submitting.

## Integration verification checklist

- In the **Chat assistant** tab, test `what is your purpose`, `how are you`, `password`, `phishing`, and `I am worried about online safety`. The first four should use the original Part 1/2 response handler; the last should use sentiment support.
- Test `add task review privacy settings`, `remind me to update my password`, `show tasks`, and `show activity log`. The activity command now displays up to ten recent records **in the chat**, not only in the Activity tab.
- Open the quiz tab, answer all 12 questions, and confirm score and feedback.
- Create, edit, complete and delete a task in the task tab. Confirm database records in MySQL Workbench.
- Verify all functionality in Visual Studio 2022 before submission; no Windows/.NET build was available in the creation environment.
